# Proyecto Hackathon - Medalid Chaparro
Estructura estándar generada automáticamente.